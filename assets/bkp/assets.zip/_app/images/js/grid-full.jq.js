// Get the modal
var modal = document.getElementById('myModal');
var modalImg = document.getElementById("img-full");
var captionText = document.getElementById("caption");
var menuSec = document.getElementById('menu-section');

var singleMode = false;

var resCtns = $('.resp-container');
var resSecs = new Array();

var i;
var j;
for (i = 0; i < resCtns.length; ++i) {
	var resCtn = $(resCtns[i]);	

	resSecs.push(resCtn.find('.responsive img'));
	for (j = 0; j < resSecs[i].length; ++j) {
		if (j < 7) {
			$(resSecs[i][j]).closest('.responsive').addClass('prev' + (j + 1));
		}  else {
			$(resSecs[i][j]).closest('.responsive').addClass('prevHide');			
		}
	}
}

divSize();

function divSize() {
	// console.log('sizing')
    var textCtn = $('.text-container');

    $('.resp-container').each(function(index) {

    	var resCtn = $(this);
        var chImg = resCtn.children('.responsive');
    	var imgSize = chImg.outerWidth(true);
    	var ctnSize = resCtn.width()
    	
    	if (chImg == undefined) return;

    
		var maxElems = ~~(textCtn.width() / imgSize);

        // console.log(index);
        // console.log('maxElems ' + maxElems)
        // console.log('textCtn ' + textCtn.width())
        // console.log('chImg ' + chImg.length)

        displayMobile();

        if (maxElems > 2) {
        	if (chImg.length > 6) {
        		resCtn.removeClass('trio duo tar');
        		resCtn.addClass('multi');
        	} else {
	        	resCtn.removeClass('multi duo tar');
	        	if (chImg.length > 3) {
	        		resCtn.addClass('trio');
	        	}
	        }
        } else if (maxElems > 1) {
        	resCtn.removeClass('multi trio tar');
        	if (chImg.length > 2) {
        		resCtn.addClass('duo');
        	}
        } else {
        	resCtn.removeClass('multi trio duo');
        	if (chImg.length > 1) {
        		resCtn.addClass('tar');
        	}        	
        }

    });
}

function displayMobile() {
	if ($(window).width() < 720) {
		// console.log('mobile mode');
		$('.text-prev-img').each(function(index) {
			$(this).removeClass('text-prev-img').addClass('text-prev-mob');
			$(this).children('.prev-text').removeClass('prev-text').addClass('text-mob');
			$(this).children('.prev-img').css('display', 'none');
		});
	} else {
		$('.text-prev-mob').each(function(index) {
			$(this).removeClass('text-prev-mob').addClass('text-prev-img');
			$(this).children('.text-mob').removeClass('text-mob').addClass('prev-text');
			$(this).children('.prev-img').css('display', 'block');
		});
	}
}

$(window).resize(function() {
	divSize();
	// var ww = $(window).width();
	// var resCtn = $('.resp-container');
	// if (ww > 1200) {
	// 	resCtn.css('width', '');
	// }

  // if (ww <= 1200) {
    // for (i = 0; i < resCtns.length; ++i) {
      // var resCtn = $(resCtns[i]);
      // resCtn.children('.responsive').css('width', '');
    // }
  // } else {
    // divSize();
  // }
});

// retrieve the parent of the img section

	var imgs = resSecs[0];
	var curImg = 0;

  $('.responsive img').click(function() {
  	// we need to load the correct sequence of images
  	var curCtn = $(this).closest('.resp-container');
  	imgs = resSecs[resCtns.index(curCtn)];

    // get the current img index
    curImg = imgs.index($(this));

    $("body").css("overflow", "hidden");

    displayImg(this);
  });

  $('.text-prev-img img').click(function() {
    $("body").css("overflow", "hidden");

    singleMode = true;
    displayImg(this);
  });


  function displayImg(e, mode) {
  	menuSec.style.display = 'none';

  	if (singleMode) {
    	$('#prevBtn, #nextBtn').css('display', 'none');
  	}
    // function
    modal.style.display = "block";
    modalImg.src = e.getAttribute("data-src");
    captionText.innerHTML = e.alt;
  }

  function nextImg() {
    if (singleMode) return;

  	if (modal.style.display != 'block') return;
  	curImg ++;
  	if (curImg == imgs.length) {
  		curImg = 0;
  	}
  	displayImg(imgs[curImg]);
  }
  function prevImg() {
    if (singleMode) return;
    
  	if (modal.style.display != 'block') return;
  	curImg --;
  	if (curImg < 0) {
  		curImg = imgs.length - 1;
  	}
  	displayImg(imgs[curImg]);
  }

$('#closeBtn').click(closeFull);

  function closeFull() {
    menuSec.style.display = 'block';
    modal.style.display = "none";
    if (singleMode) {
    	$('#prevBtn, #nextBtn').css('display', 'initial');
    	singleMode = false;
    }
    $("body").css("overflow", "auto");
  }

$(function(){

var myModal = $('div');


  // Keyboard navigation
  $('body').keydown(function(e) {
    if (e.keyCode == 37) {
      prevImg(); // Left arrow
    }
    else if(e.keyCode == 39) { // right
    	nextImg(); // Right arrow
    }
    else if(e.keyCode == 27) { // right
      closeFull(); // ESC
    }
  });

  myModal.on('swipeleft', function() {
    nextImg(); // Next img
  });
  myModal.on('swiperight', function() {
    prevImg(); // Previous img
  });
  myModal.on('swipedown', function() {
  	closeFull(); // Close gallery
  });
  myModal.on('swipeup', function() {
    closeFull(); // Close gallery
  });
  myModal.click(function() {
    // console.log('click');
  });
});